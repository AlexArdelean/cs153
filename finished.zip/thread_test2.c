#include "param.h"
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "fcntl.h"
#include "syscall.h"
#include "traps.h"
#include "memlayout.h"

void TestThread1(void * arg_ptr);
void TestThread2(void * arg_ptr);
void TestThread3(void * arg_ptr);

int main()
{
	void * tid1 = thread_create(TestThread1, (void*) 0);
	if(tid1 == 0) 
	{
		printf(1, "thread_create failed.\n");
		exit();
	}
	
	void * tid2 = thread_create(TestThread2, (void*) 0);
	if(tid2 == 0) 
	{
		printf(1, "thread_create failed.\n");
		exit();
	}

	void * tid3 = thread_create(TestThread3, (void*) 0);
	if(tid3 == 0) 
	{
		printf(1, "thread_create failed.\n");
		exit();
	}

	while(wait()>0);

	exit();
	return 0;
}

void TestThread1(void * arg_ptr)
{
	printf(1, "Thread 1 starts...\n");
	printf(1, "Thread 1 yielding...\n");
	thread_yield();

		
	printf(1, "Thread 1 resuming...\n");
	printf(1, "Thread 1 ends...\n");

	texit();
}

void TestThread2(void * arg_ptr)
{
	printf(1, "Thread 2 starts...\n");
	printf(1, "Thread 2 yielding...\n");
	thread_yield();

	
	printf(1, "Thread 2 resumes...\n");
	printf(1, "Thread 2 ends...\n");

	texit();
}

void TestThread3(void * arg_ptr)
{
	printf(1, "Thread 3 starts...\n");
	printf(1, "Thread 3 ends...\n");

	texit();
}
