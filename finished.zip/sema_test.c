#include "semaphore.h"

int main()
{
	//struct Semaphore * s = malloc(sizeof(struct Semaphore));
	
	// change to thread_create instead of fork
	// write a test_func for the thread
	
	exit();
	return 0;
}
