#include "semaphore.h"

void Monkey(void * arg_ptr);
void DomMonkey(void * arg_ptr);

struct Semaphore s_t; 

struct mutex 
{
	lock_t lock;
} mutex;


int main()
{
	sem_init(&s_t, 3);	
	lock_init(&mutex.lock);

	printf(1, "start ...\n");
	void * tid2 = thread_create(Monkey, (void*) 0);
	if(tid2 == 0) 
	{
		printf(1, "thread_create failed.\n");
		exit();
	}

	void * tid3 = thread_create(Monkey, (void*) 0);
	if(tid3 == 0) 
	{
		printf(1, "thread_create failed.\n");
		exit();
	}

	void * tid1 = thread_create(Monkey, (void*) 0);
	if(tid1 == 0) 
	{
		printf(1, "thread_create failed.\n");
		exit();
	}

	void * tid4 = thread_create(Monkey, (void*) 0);
	if(tid4 == 0) 
	{
		printf(1, "thread_create failed.\n");
		exit();
	}
	void * tid5 = thread_create(Monkey, (void*) 0);
	if(tid5 == 0) 
	{
		printf(1, "thread_create failed.\n");
		exit();
	}

	void * tid6 = thread_create(Monkey, (void*) 0);
	if(tid6 == 0) 
	{
		printf(1, "thread_create failed.\n");
		exit();
	}

	void * tid7 = thread_create(Monkey, (void*) 0);
	if(tid7 == 0) 
	{
		printf(1, "thread_create failed.\n");
		exit();
	}

	void * tid8 = thread_create(Monkey, (void*) 0);
	if(tid8 == 0) 
	{
		printf(1, "thread_create failed.\n");
		exit();
	}
	
	void * tid9 = thread_create(Monkey, (void*) 0);
	if(tid9 == 0) 
	{
		printf(1, "thread_create failed.\n");
		exit();
	}

	void * tid10 = thread_create(DomMonkey, (void*) 0);
	if(tid10 == 0) 
	{
		printf(1, "thread_create failed.\n");
		exit();
	}


	while(wait()>0);
//	printf(1, "count = %d\n", count);
	exit();
	return 0;
}

void Monkey(void * arg_ptr)
{
	printf(1, "Monkey arrives!\n");
	
	sem_acquire(&s_t);
	sleep(10);

	lock_acquire(&mutex.lock);
	printf(1, "Grabbed coconut!\n");
	lock_release(&mutex.lock);
	sem_signal(&s_t);

	texit();
}

void DomMonkey(void * arg_ptr)
{	
	printf(1, "Dominant monkey arrives!\n");

	sem_dom_acquire(&s_t);

	lock_acquire(&mutex.lock);
	printf(1, "Dominant monkey grabbed coconut!\n");
	lock_release(&mutex.lock);

	sem_signal(&s_t);

	texit();
}
