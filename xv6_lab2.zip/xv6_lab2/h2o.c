#include "semaphore.h"

void O_ready(void * arg_ptr);
void H_ready(void * arg_ptr);

struct Semaphore s_h; 
struct Semaphore s_o;

struct mutex 
{
	lock_t lock;
} mutex;

int count = 0;

int main()
{
	sem_init(&s_h, 1);	
	sem_init(&s_o, 1);	

	void * tid1 = thread_create(O_ready, (void*) 0);
	if(tid1 == 0) 
	exit();
	wait();

	void * tid2 = thread_create(H_ready, (void*) 0);
	if(tid2 == 0) 
	exit();
	wait();
	/*	
	void * tid3 = thread_create(H_ready, (void*) 0);
	if(tid3 == 0) 
	exit();
	wait();
	*/
	printf(1, "count = %d\n", count);

	exit();
	return 0;
}

void O_ready(void * arg_ptr)
{
	sem_acquire(&s_h);
	sem_acquire(&s_h);
	sem_signal(&s_o);
	sem_signal(&s_o);
	lock_acquire(&mutex.lock);
	count++;
	lock_release(&mutex.lock);

	texit();
}

void H_ready(void * arg_ptr)
{
	sem_signal(&s_h);
	sem_acquire(&s_o);
	texit();
}
